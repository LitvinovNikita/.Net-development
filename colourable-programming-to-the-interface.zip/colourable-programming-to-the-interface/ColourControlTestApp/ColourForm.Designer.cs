﻿namespace ColourControlTestApp
{
    partial class ColourForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.colourControl = new ColourControl.ColourControl();
            this.SuspendLayout();
            // 
            // colourControl
            // 
            this.colourControl.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.colourControl.ColourableTarget = null;
            this.colourControl.Location = new System.Drawing.Point(12, 22);
            this.colourControl.Name = "colourControl";
            this.colourControl.Size = new System.Drawing.Size(574, 186);
            this.colourControl.TabIndex = 0;
            // 
            // ColourForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 234);
            this.Controls.Add(this.colourControl);
            this.Name = "ColourForm";
            this.Text = "ColourForm";
            this.ResumeLayout(false);

        }

        #endregion

        private ColourControl.ColourControl colourControl;
    }
}