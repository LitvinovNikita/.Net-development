using ColourControl;

namespace ColourControlTestApp
{
    public partial class MainForm : Form, IColourable
    {
        public MainForm()
        {
            InitializeComponent();
        }

        public Color Color
        { 
            get
            {
                return this.BackColor;
            }
            set
            {
                this.BackColor = value;
            }
        }

        private void btnColourForm_Click(object sender, EventArgs e)
        {
            // Create a child ColourForm object, pass this form
            // object as a param (because it is IColourable)
            ColourForm colourForm = new ColourForm(this);

            // and then show the form:
            colourForm.Show();
        }
    }
}