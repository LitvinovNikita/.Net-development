﻿using ColourControl;

namespace ColourControlTestApp
{
    public partial class ColourForm : Form
    {
        /// <summary>
        /// This form simply houses the colour control
        /// and accepts the colourable target as a 
        /// constructor param and then, in turn, sets
        /// that target on the colour control.
        /// </summary>
        public ColourForm(IColourable colourableTarget)
        {
            InitializeComponent();

            colourControl.ColourableTarget = colourableTarget;
        }
    }
}
