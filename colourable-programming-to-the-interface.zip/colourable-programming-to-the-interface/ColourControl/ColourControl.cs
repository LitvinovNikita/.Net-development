﻿namespace ColourControl
{
    public partial class ColourControl : UserControl
    {
        public ColourControl()
        {
            InitializeComponent();

            trackBarRed.Minimum = 0;
            trackBarRed.Maximum = 255;
            trackBarRed.SmallChange = 10;
            trackBarRed.LargeChange = 50;
            trackBarRed.Value = 0;
            txtRed.Text = "0";
            txtRed.BackColor = Color.FromArgb(0, 0, 0);

            trackBarGreen.Minimum = 0;
            trackBarGreen.Maximum = 255;
            trackBarGreen.SmallChange = 10;
            trackBarGreen.LargeChange = 50;
            trackBarGreen.Value = 0;
            txtGreen.Text = "0";
            txtGreen.BackColor = Color.FromArgb(0, 0, 0);

            trackBarBlue.Minimum = 0;
            trackBarBlue.Maximum = 255;
            trackBarBlue.SmallChange = 10;
            trackBarBlue.LargeChange = 50;
            trackBarBlue.Value = 0;
            txtBlue.Text = "0";
            txtBlue.BackColor = Color.FromArgb(0, 0, 0);
        }

        public IColourable ColourableTarget
        {
            get
            {
                return _colourableTarget;
            }
            set
            {
                // set the target using the value but aslo set 
                // all the trackbars & text fields accordingly:
                _colourableTarget = value;
                if (_colourableTarget != null)
                {
                    int r = _colourableTarget.Color.R;
                    int g = _colourableTarget.Color.G;
                    int b = _colourableTarget.Color.B;

                    trackBarRed.Value = r;
                    txtRed.Text = r.ToString();
                    txtRed.BackColor = Color.FromArgb(r, 0, 0);

                    trackBarGreen.Value = g;
                    txtGreen.Text = g.ToString();
                    txtGreen.BackColor = Color.FromArgb(0, g, 0);

                    trackBarBlue.Value = b;
                    txtBlue.Text = b.ToString();
                    txtBlue.BackColor = Color.FromArgb(0, 0, b);
                }
            }
        }

        // This is called everytime the user scrolls the trackbar:
        private void trackBarRed_Scroll(object sender, EventArgs e)
        {
            int r = trackBarRed.Value;
            int g = trackBarGreen.Value;
            int b = trackBarBlue.Value;

            txtRed.Text = r.ToString();
            txtRed.BackColor = Color.FromArgb(r, 0, 0);

            UpdateTarget(r, g, b);
        }

        // A private helper method that updates the color on the colourable target:
        private void UpdateTarget(int redValue, int greenValue, int blueValue)
        {
            if (_colourableTarget != null)
            {
                _colourableTarget.Color = Color.FromArgb(redValue, greenValue, blueValue);
            }
        }

        private IColourable? _colourableTarget = null;

        private void ColourControl_Load(object sender, EventArgs e)
        {
        }

        private void trackBarGreen_Scroll(object sender, EventArgs e)
        {
            int r = trackBarRed.Value;
            int g = trackBarGreen.Value;
            int b = trackBarBlue.Value;

            txtGreen.Text = g.ToString();
            txtGreen.BackColor = Color.FromArgb(0, g, 0);

            UpdateTarget(r, g, b);
        }

        private void trackBarBlue_Scroll(object sender, EventArgs e)
        {
            int r = trackBarRed.Value;
            int g = trackBarGreen.Value;
            int b = trackBarBlue.Value;

            txtBlue.Text = b.ToString();
            txtBlue.BackColor = Color.FromArgb(0, 0, b);

            UpdateTarget(r, g, b);
        }
    }
}