﻿namespace ColourControl
{
    partial class ColourControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblRed = new System.Windows.Forms.Label();
            this.trackBarRed = new System.Windows.Forms.TrackBar();
            this.txtRed = new System.Windows.Forms.TextBox();
            this.txtGreen = new System.Windows.Forms.TextBox();
            this.trackBarGreen = new System.Windows.Forms.TrackBar();
            this.lblGreen = new System.Windows.Forms.Label();
            this.txtBlue = new System.Windows.Forms.TextBox();
            this.trackBarBlue = new System.Windows.Forms.TrackBar();
            this.lblBlue = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarRed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarGreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarBlue)).BeginInit();
            this.SuspendLayout();
            // 
            // lblRed
            // 
            this.lblRed.AutoSize = true;
            this.lblRed.Location = new System.Drawing.Point(26, 32);
            this.lblRed.Name = "lblRed";
            this.lblRed.Size = new System.Drawing.Size(30, 15);
            this.lblRed.TabIndex = 0;
            this.lblRed.Text = "Red:";
            // 
            // trackBarRed
            // 
            this.trackBarRed.Location = new System.Drawing.Point(78, 17);
            this.trackBarRed.Name = "trackBarRed";
            this.trackBarRed.Size = new System.Drawing.Size(322, 45);
            this.trackBarRed.TabIndex = 1;
            this.trackBarRed.Scroll += new System.EventHandler(this.trackBarRed_Scroll);
            // 
            // txtRed
            // 
            this.txtRed.Location = new System.Drawing.Point(424, 24);
            this.txtRed.Name = "txtRed";
            this.txtRed.Size = new System.Drawing.Size(72, 23);
            this.txtRed.TabIndex = 2;
            // 
            // txtGreen
            // 
            this.txtGreen.Location = new System.Drawing.Point(424, 75);
            this.txtGreen.Name = "txtGreen";
            this.txtGreen.Size = new System.Drawing.Size(72, 23);
            this.txtGreen.TabIndex = 5;
            // 
            // trackBarGreen
            // 
            this.trackBarGreen.Location = new System.Drawing.Point(78, 68);
            this.trackBarGreen.Name = "trackBarGreen";
            this.trackBarGreen.Size = new System.Drawing.Size(322, 45);
            this.trackBarGreen.TabIndex = 4;
            this.trackBarGreen.Scroll += new System.EventHandler(this.trackBarGreen_Scroll);
            // 
            // lblGreen
            // 
            this.lblGreen.AutoSize = true;
            this.lblGreen.Location = new System.Drawing.Point(26, 83);
            this.lblGreen.Name = "lblGreen";
            this.lblGreen.Size = new System.Drawing.Size(41, 15);
            this.lblGreen.TabIndex = 3;
            this.lblGreen.Text = "Green:";
            // 
            // txtBlue
            // 
            this.txtBlue.Location = new System.Drawing.Point(424, 126);
            this.txtBlue.Name = "txtBlue";
            this.txtBlue.Size = new System.Drawing.Size(72, 23);
            this.txtBlue.TabIndex = 8;
            // 
            // trackBarBlue
            // 
            this.trackBarBlue.Location = new System.Drawing.Point(78, 119);
            this.trackBarBlue.Name = "trackBarBlue";
            this.trackBarBlue.Size = new System.Drawing.Size(322, 45);
            this.trackBarBlue.TabIndex = 7;
            this.trackBarBlue.Scroll += new System.EventHandler(this.trackBarBlue_Scroll);
            // 
            // lblBlue
            // 
            this.lblBlue.AutoSize = true;
            this.lblBlue.Location = new System.Drawing.Point(26, 134);
            this.lblBlue.Name = "lblBlue";
            this.lblBlue.Size = new System.Drawing.Size(33, 15);
            this.lblBlue.TabIndex = 6;
            this.lblBlue.Text = "Blue:";
            // 
            // ColourControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Controls.Add(this.txtBlue);
            this.Controls.Add(this.trackBarBlue);
            this.Controls.Add(this.lblBlue);
            this.Controls.Add(this.txtGreen);
            this.Controls.Add(this.trackBarGreen);
            this.Controls.Add(this.lblGreen);
            this.Controls.Add(this.txtRed);
            this.Controls.Add(this.trackBarRed);
            this.Controls.Add(this.lblRed);
            this.Name = "ColourControl";
            this.Size = new System.Drawing.Size(574, 186);
            this.Load += new System.EventHandler(this.ColourControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.trackBarRed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarGreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarBlue)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lblRed;
        private TrackBar trackBarRed;
        private TextBox txtRed;
        private TextBox txtGreen;
        private TrackBar trackBarGreen;
        private Label lblGreen;
        private TextBox txtBlue;
        private TrackBar trackBarBlue;
        private Label lblBlue;
    }
}