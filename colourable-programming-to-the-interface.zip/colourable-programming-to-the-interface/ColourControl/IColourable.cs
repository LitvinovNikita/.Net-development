﻿using System.Drawing;

namespace ColourControl
{
    /// <summary>
    /// An interface that defines the behaviour of "colourable things",
    /// i.e. things that can be coloured.
    /// </summary>
    public interface IColourable
    {
        /// <summary>
        /// A property named Color of type Color.
        /// Note: we don't need to declare it public explicitly - it is already
        /// </summary>
        Color Color
        { 
            get;
            set;
        }
    }
}
